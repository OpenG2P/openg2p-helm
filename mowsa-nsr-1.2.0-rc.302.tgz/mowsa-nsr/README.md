# mowsa-nsr

Thin Helm wrapper for the **MoWSA National Social Registry**.

## What this chart owns

| Piece | Role |
|-------|------|
| `openg2p-registry` dependency (alias `registry`) | All registry services, IAM wiring, db-seed, id-generator, … |
| Values overlay | MoWSA images, hostname, id pools, IAM tile name, seed toggles |
| `templates/connector/*` | MoWSA connector stack (ODK / WebSub → Partner API) |

## Install

```bash
helm repo add openg2p https://openg2p.github.io/openg2p-helm
helm dependency build ./helm/mowsa-nsr
helm install mowsa-nsr ./helm/mowsa-nsr \
  --set global.registryHostname=nsr.example.org
```

Images: `openg2p/openg2p-mowsa-nsr-{staff-portal-api,partner-api,celery,db-seed}` on Docker Hub.
Each image extends the matching `openg2p/openg2p-registry-*` base at the pinned
`RP_VERSION` / chart dependency version.
