import os
import sys
import importlib

def get_app():
    app_path = os.environ.get("CELERY_APP")
    if not app_path:
        print("Error: CELERY_APP environment variable is not set.")
        sys.exit(1)
    
    try:
        # Support both module:attr and module.attr
        if ":" in app_path:
            module_name, app_attr = app_path.split(":", 1)
        else:
            module_name, app_attr = app_path.rsplit(".", 1)
            
        module = importlib.import_module(module_name)
        return getattr(module, app_attr)
    except Exception as e:
        print(f"Error loading Celery app '{app_path}': {e}")
        sys.exit(1)

def patch_awe_bearer_from_keycloak() -> None:
    """Partner ingest finalize has no user bearer; fetch client-credentials token."""
    import json
    import urllib.parse
    import urllib.request

    from openg2p_registry_core.errors import G2PRegistryErrorCodes, G2PRegistryException
    from openg2p_registry_core.services.g2p_awe_integration_service import (
        G2PAweIntegrationService,
    )

    token_url = (os.environ.get("REGISTRY_CORE_KEYCLOAK_TOKEN_URL") or "").strip()
    client_id = (os.environ.get("REGISTRY_CORE_KEYCLOAK_CLIENT_ID") or "").strip()
    client_secret = (os.environ.get("REGISTRY_CORE_KEYCLOAK_CLIENT_SECRET") or "").strip()
    if not all([token_url, client_id, client_secret]):
        return

    def _fetch_token() -> str:
        data = urllib.parse.urlencode(
            {
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            }
        ).encode()
        req = urllib.request.Request(token_url, data=data, method="POST")
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())["access_token"]

    def _require_bearer(self, bearer_token: str | None) -> str:
        token = (bearer_token or "").strip() or _fetch_token()
        if not token:
            raise G2PRegistryException(
                code=G2PRegistryErrorCodes.AWE_BEARER_TOKEN_REQUIRED.value[1],
                message=G2PRegistryErrorCodes.AWE_BEARER_TOKEN_REQUIRED.value[0],
            )
        return token

    G2PAweIntegrationService._require_bearer = _require_bearer


def ensure_registry_services():
    """Register intake/AWE services omitted by the celery worker Initializer."""
    from openg2p_registry_core.helpers import AweHelper
    from openg2p_registry_core.services.g2p_awe_integration_service import (
        G2PAweIntegrationService,
    )
    from openg2p_registry_core.services.g2p_awe_policy_configuration_service import (
        G2PAwePolicyConfigurationService,
    )
    from openg2p_registry_core.services.g2p_verification_service import (
        G2PRegisterVerificationService,
    )
    from openg2p_registry_core.services.intake_form_data_service import (
        G2PIntakeFormDataService,
    )

    if G2PAwePolicyConfigurationService.get_component() is None:
        G2PAwePolicyConfigurationService()
    if G2PAweIntegrationService.get_component() is None:
        G2PAweIntegrationService()
    if G2PIntakeFormDataService.get_component() is None:
        G2PIntakeFormDataService()
    if G2PRegisterVerificationService.get_component() is None:
        G2PRegisterVerificationService()
    if AweHelper.get_component() is None:
        AweHelper()
    patch_awe_bearer_from_keycloak()


def patch_ingest_finalize() -> None:
    """Ensure AWE services exist before partner-ingest finalize (prefork-safe)."""
    import importlib

    idw = importlib.import_module("openg2p_registry_celery_workers.tasks.ingest_data_worker")

    original_finalize = getattr(idw, "_finalize_submission_async", None)
    if original_finalize is not None and not getattr(
        original_finalize, "_awe_services_patched", False
    ):

        async def finalize_with_services(submission_id: str, session) -> None:
            ensure_registry_services()
            return await original_finalize(submission_id, session)

        finalize_with_services._awe_services_patched = True
        idw._finalize_submission_async = finalize_with_services

    original_process = getattr(idw, "_process_ingestion_async", None)
    if original_process is not None and not getattr(
        original_process, "_awe_services_patched", False
    ):

        async def process_with_services(ingest_id: str) -> None:
            ensure_registry_services()
            patch_ingest_finalize()
            return await original_process(ingest_id)

        process_with_services._awe_services_patched = True
        idw._process_ingestion_async = process_with_services


def setup_worker_process_init(celery_app):
    """Register services in each prefork worker child (not inherited from parent)."""
    from celery.signals import worker_process_init

    @worker_process_init.connect(weak=False)
    def _register_services_on_fork(**kwargs):
        ensure_registry_services()
        patch_ingest_finalize()


def setup_task_prerun(celery_app):
    """Fallback: ensure services before every task (prefork child init can be unreliable)."""
    from celery.signals import task_prerun

    @task_prerun.connect(weak=False)
    def _register_services_before_task(**kwargs):
        ensure_registry_services()
        patch_ingest_finalize()


def main():
    celery_app = get_app()
    patch_ingest_finalize()
    setup_worker_process_init(celery_app)
    setup_task_prerun(celery_app)
    ensure_registry_services()

    # Add dynamic imports
    imports_str = os.environ.get("CELERY_IMPORTS", "")
    extra_imports = [i.strip() for i in imports_str.split(",") if i.strip()]
    
    if extra_imports:
        print(f"Adding imports: {extra_imports}")
        # Ensure include is a list
        current_include = list(celery_app.conf.include) if celery_app.conf.include else []
        celery_app.conf.update(include=current_include + extra_imports)
    
    # Run the worker/beat
    opts = os.environ.get("CELERY_OPTS", "worker --loglevel=info").split()
    print(f"Starting Celery with options: {opts}")
    
    # celery_app.start(argv=...) passes arguments to click.
    # Click expects the first argument to be the subcommand (e.g. 'worker').
    # We do NOT pass the program name 'celery' here.
    try:
        celery_app.start(argv=opts)
    except Exception as e:
        print(f"Error starting via app.start(): {e}")
        raise

if __name__ == "__main__":
    main()
