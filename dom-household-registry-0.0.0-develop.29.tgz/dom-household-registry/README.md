# dom-household-registry

Thin Helm wrapper for the **DOM Household Registry**.

## What this chart owns

| Piece | Role |
|-------|------|
| `openg2p-registry` dependency (alias `registry`) | All registry services, IAM wiring, db-seed, id-generator, … |
| Values overlay | DOM images, hostname, id pools, IAM tile name, seed toggles |
| `templates/connector/*` | DOM connector stack (ODK / WebSub → Partner API) |

## Install

```bash
helm repo add openg2p https://openg2p.github.io/openg2p-helm
helm dependency build ./helm/dom-household-registry
helm install dom-household-registry ./helm/dom-household-registry \
  --set global.registryHostname=dom-hh.example.org
```

Images: `openg2p/openg2p-dom-household-registry-{staff-portal-api,partner-api,celery,db-seed}` on Docker Hub.
Each image extends the matching `openg2p/openg2p-registry-*` base at the pinned
`RP_VERSION` / chart dependency version.
