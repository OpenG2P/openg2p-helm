# OpenG2P Livestock Registry

The livestock department's registry, built on the OpenG2P registry platform:

* **Animal** register: Animal ID (generated, ten digits), ear tag, species, breed,
  sex, date of birth, mother, how it was acquired, and its owner (the Farmer
  Registry's Farmer ID with the owner's national ID) and where it is kept.
  Every change, a change of owner included, is approved in AWE.
* **Veterinarian** register: the vets and animal health workers who vaccinate
  and treat (Vet ID, eight digits).
* **LivestockEvent** activity register: births, vaccinations, treatments, sales
  and deaths, against the animal, with each animal's current state.

Coded fields are Master Data lists (`LIVESTOCK_*`, the country pack's agriculture
domain): install Master Data with `geoSeed.domains: [agriculture]` first. Partners
read a farmer's animals over DCI with the farmer's consent.
