Mimoto Installation.
